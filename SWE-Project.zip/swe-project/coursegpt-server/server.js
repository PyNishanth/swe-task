const express = require('express');
const cors = require('cors');
require('dotenv').config();  // Load environment variables

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({
  origin: 'http://localhost:5173',  // Allow requests from your frontend
}));

app.use(express.json());

app.post('/generate-lesson', async (req, res) => {
  const prompt = req.body.prompt;

  try {
    const options = {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`,  // API key from env variables
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'sonar',  // Correct model name
        messages: [
          { role: 'system', content: 'Be precise and concise.' },
          { role: 'user', content: prompt }
        ]
      })
    };

    const response = await fetch('https://api.perplexity.ai/chat/completions', options);
    const data = await response.json();

    // Check if the response contains the generated text and send it back
    if (data && data.choices && data.choices[0] && data.choices[0].message) {
      res.json({ generated_text: data.choices[0].message.content });
    } else {
      res.status(400).json({ error: 'Failed to generate lesson' });
    }
  } catch (error) {
    console.error('Error details:', error.message);
    res.status(500).json({ error: 'Failed to generate lesson', details: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Backend server is running on http://localhost:${PORT}`);
});
