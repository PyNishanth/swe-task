import { useState } from "react";
import "./App.css";  // Import CSS for styling

const App = () => {
  const [prompt, setPrompt] = useState("");
  const [lesson, setLesson] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerateLesson = async () => {
    if (!prompt) return alert("Please enter a topic for the lesson");

    setIsLoading(true);
    try {
      const response = await fetch("http://localhost:5000/generate-lesson", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt }),
      });

      const data = await response.json();
      setLesson(data.generated_text);
    } catch (error) {
      console.error(error);
      alert("Error generating lesson");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>CourseGPT - AI-Powered Lesson Generator</h1>
      </header>
      <main className="main-content">
        <div className="input-container">
          <textarea
            className="input-field"
            placeholder="Enter course topic or lesson idea"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
          <button
            className={`generate-button ${isLoading ? "loading" : ""}`}
            onClick={handleGenerateLesson}
            disabled={isLoading}
          >
            {isLoading ? "Generating..." : "Generate Lesson"}
          </button>
        </div>
        {lesson && (
          <div className="lesson-output">
            <h2>Generated Lesson:</h2>
            <p>{lesson}</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
